import io.grpc.stub.StreamObserver;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ConcurrentHashMap;

public class MessageServiceImpl extends MessageServiceGrpc.MessageServiceImplBase {

    private ConcurrentHashMap<String, List<Message>> messageStore = new ConcurrentHashMap<>();

    @Override
    public void sendMessage(Message request, StreamObserver<Message> responseObserver) {
        // Ajouter la logique pour envoyer le message � un destinataire sp�cifi�
        String recipientId = request.getRecipientId();
        List<Message> messages = messageStore.computeIfAbsent(recipientId, k -> new ArrayList<>());
        messages.add(request);
        responseObserver.onNext(request);
        responseObserver.onCompleted();
    }

    @Override
    public void getMessagesForUser(String userId, StreamObserver<Message> responseObserver) {
        // R�cup�rer les messages re�us pour un utilisateur donn�
        List<Message> messages = messageStore.getOrDefault(userId, new ArrayList<>());
        for (Message message : messages) {
            responseObserver.onNext(message);
        }
        responseObserver.onCompleted();
    }
}
