import io.grpc.ManagedChannel;
import io.grpc.ManagedChannelBuilder;
import io.grpc.stub.StreamObserver;

public class GetMessagesClient {

    public static void main(String[] args) {
        ManagedChannel channel = ManagedChannelBuilder.forAddress("localhost", 8080)
                .usePlaintext()
                .build();

        MessageServiceGrpc.MessageServiceStub stub = MessageServiceGrpc.newStub(channel);

        stub.getMessagesForUser("recipient456", new StreamObserver<Message>() {
            @Override
            public void onNext(Message message) {
                System.out.println("Message re�u : " + message);
            }

            @Override
            public void onError(Throwable throwable) {
                System.out.println("Erreur lors de la r�cup�ration des messages : " + throwable.getMessage());
            }

            @Override
            public void onCompleted() {
                channel.shutdown();
            }
        });
    }
}
