import io.grpc.Server;
import io.grpc.ServerBuilder;
import java.io.IOException;

public class MessageServer {

    public static void main(String[] args) throws IOException, InterruptedException {
        Server server = ServerBuilder.forPort(8080)
                .addService(new MessageServiceImpl())
                .build();

        server.start();
        System.out.println("Serveur gRPC d�marr� sur le port 8080");
        server.awaitTermination();
    }
}
