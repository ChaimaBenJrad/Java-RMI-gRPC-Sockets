import io.grpc.ManagedChannel;
import io.grpc.ManagedChannelBuilder;
import io.grpc.stub.StreamObserver;

public class SendMessageClient {

    public static void main(String[] args) {
        ManagedChannel channel = ManagedChannelBuilder.forAddress("localhost", 8080)
                .usePlaintext()
                .build();

        MessageServiceGrpc.MessageServiceStub stub = MessageServiceGrpc.newStub(channel);

        Message message = Message.newBuilder()
                .setSenderId("sender123")
                .setRecipientId("recipient456")
                .setText("Hello, how are you?")
                .build();

        stub.sendMessage(message, new StreamObserver<Message>() {
            @Override
            public void onNext(Message response) {
                System.out.println("Message envoy� avec succ�s : " + response);
            }

            @Override
            public void onError(Throwable throwable) {
                System.out.println("Erreur lors de l'envoi du message : " + throwable.getMessage());
            }

            @Override
            public void onCompleted() {
                channel.shutdown();
            }
        });
    }
}
