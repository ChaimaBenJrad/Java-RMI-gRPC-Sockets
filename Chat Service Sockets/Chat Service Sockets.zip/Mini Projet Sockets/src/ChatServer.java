import java.io.*;
import java.net.*;
import java.util.*;

public class ChatServer {
    private static final int PORT = 12345;
    private static Set<PrintWriter> clients = new HashSet<>();
    private static List<String> messagesHistory = new ArrayList<>();

    public static void main(String[] args) {
        try (ServerSocket serverSocket = new ServerSocket(PORT)) {
            System.out.println("Serveur de chat d�marr� sur le port " + PORT);

            while (true) {
                new ClientHandler(serverSocket.accept()).start();
            }
        } catch (IOException e) {
            System.out.println("Erreur lors du d�marrage du serveur de chat : " + e.getMessage());
        }
    }

    private static class ClientHandler extends Thread {
        private Socket socket;
        private PrintWriter out;
        private BufferedReader in;

        public ClientHandler(Socket socket) {
            this.socket = socket;
        }

        public void run() {
            try {
                in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
                out = new PrintWriter(socket.getOutputStream(), true);

                clients.add(out);

                // Envoyer l'historique des messages au nouveau client
                for (String message : messagesHistory) {
                    out.println(message);
                }

                String message;
                while ((message = in.readLine()) != null) {
                    System.out.println("Nouveau message re�u : " + message);
                    messagesHistory.add(message);
                    broadcastMessage(message);
                }
            } catch (IOException e) {
                System.out.println("Un client a quitt� le chat.");
            } finally {
                if (out != null) {
                    clients.remove(out);
                }
                try {
                    socket.close();
                } catch (IOException e) {
                    System.out.println("Erreur lors de la fermeture de la connexion client : " + e.getMessage());
                }
            }
        }

        private void broadcastMessage(String message) {
            for (PrintWriter client : clients) {
                client.println(message);
            }
        }
    }
}
