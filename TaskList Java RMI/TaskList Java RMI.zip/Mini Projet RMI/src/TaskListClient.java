import java.rmi.Naming;
import java.util.List;

public class TaskListClient {
    public static void main(String[] args) {
        try {
            TaskList taskList = (TaskList) Naming.lookup("rmi://localhost/TaskListServer");
            taskList.addTask("Faire les courses");
            taskList.addTask("R�viser pour l'examen");
            taskList.removeTask("Faire les courses");

            List<String> allTasks = taskList.getAllTasks();
            System.out.println("Liste des t�ches :");
            for (String task : allTasks) {
                System.out.println("- " + task);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
