import java.rmi.Naming;
import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.rmi.server.UnicastRemoteObject;
import java.util.ArrayList;
import java.util.List;

public class TaskListServer extends UnicastRemoteObject implements TaskList {
    private List<String> tasks;

    public TaskListServer() throws RemoteException {
        tasks = new ArrayList<>();
    }

    @Override
    public void addTask(String task) throws RemoteException {
        tasks.add(task);
    }

    @Override
    public void removeTask(String task) throws RemoteException {
        tasks.remove(task);
    }

    @Override
    public List<String> getAllTasks() throws RemoteException {
        return tasks;
    }

    public static void main(String[] args) {
        try {
            TaskListServer server = new TaskListServer();

            // Cr�ez ou obtenez le registre RMI
            Registry registry = LocateRegistry.createRegistry(1099);

            // Enregistrez l'objet distant aupr�s du registre RMI
            Naming.rebind("rmi://localhost/TaskListServer", server);
            System.out.println("Serveur RMI en cours d'ex�cution...");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
